import fetch from 'node-fetch';
import { Buffer } from 'buffer';
import fs from 'fs';
import { getFullnodeUrl, SuiClient } from '@mysten/sui.js/client';
import { Ed25519Keypair } from '@mysten/sui.js/keypairs/ed25519';
import { TransactionBlock } from '@mysten/sui.js/transactions';
import { bcs } from '@mysten/bcs';
import chalk from "chalk";
import readlineSync from "readline-sync";
const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

const mergeobject = (address) => new Promise((resolve, reject) => { fetch(`https://api.blockvision.org/v2/sui/account/coins?account=${address}`, {
  headers: {
    'accept': 'application/json',
    'x-api-key': 'isi apikeymu'
  }
}).then(res => res.json())
        .then(res => {
            resolve(res)
        })
        .catch(err => reject(err));
});


console.log("============================================================================");
const keypair = Ed25519Keypair.deriveKeypair("isi phrasemu");
const address = keypair.getPublicKey().toSuiAddress()
console.log("Address : " + address);
const client = new SuiClient({
	url: "https://fullnode.mainnet.sui.io",
});

const getobj = await mergeobject(address);
const objt = getobj.result.coins
let jumlahobj = 0;
for (let c = 0; c < objt.length; c++) {
if(objt[c].symbol == "OCEAN"){
jumlahobj = getobj.result.coins[c].objects;
}
}
let hitung
hitung = jumlahobj / 50;
hitung = Math.floor(hitung)
console.log("Merge Sebanyak : " + hitung)
console.log("============================================================================");
for (let i = 0; i < hitung; i++) {


const coins = await client.getCoins({
	owner: address,
	coinType: '0xa8816d3a6e3136e86bc2873b1f94a15cadc8af2703c075f2d546c2ae367f4df9::ocean::OCEAN',
});
	
const mergein = [];
const hiirt = coins.data;
const huxzp = hiirt.length - 1;
//console.log(hiirt)
for (let c = 1; c < huxzp; c++) {
mergein.push(coins.data[c].coinObjectId);
//console.log(coins.data[c].coinObjectId)
}

const mergein2 = coins.data[0].coinObjectId;


const tx = new TransactionBlock();
const gasBudget = '20000000';


tx.mergeCoins(mergein2, mergein,
);

tx.setGasBudget(gasBudget);
tx.setSender(address);

const result = await client.signAndExecuteTransactionBlock({
	signer: keypair,
	transactionBlock: tx,
});
const txsk = { result }
console.log(chalk.green(`Sukses Merge  => https://suiscan.xyz/mainnet/tx/${txsk.result.digest}`));
await delay(30000);
}

const oceans = await client.getBalance({
	owner: address,
	coinType: '0xa8816d3a6e3136e86bc2873b1f94a15cadc8af2703c075f2d546c2ae367f4df9::ocean::OCEAN',
});
//console.log(oceans);
let oceansx;
oceansx = oceans.totalBalance;
oceansx = oceansx / 1000000000
oceansx = parseFloat(oceansx)
console.log("OCEANS Balance : " + oceansx.toFixed(2));
console.log("============================================================================");